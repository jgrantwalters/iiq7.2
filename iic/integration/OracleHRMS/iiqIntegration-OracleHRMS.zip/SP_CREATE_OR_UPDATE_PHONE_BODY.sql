create or replace Package Body sp_create_or_update_phone as
--
-- Package Variables
--
g_package  varchar2(33) := 'sp_create_or_update_phone';
g_debug boolean := hr_utility.debug_enabled;
--
-- ----------------------------------------------------------------------------
-- |---------------------------< create_or_update_phone >------------------------------|
-- ----------------------------------------------------------------------------
--
procedure create_or_update_phone (
    p_date_from                    in date,
    p_phone_type                   in varchar2,
    p_phone_number                 in varchar2,
    p_parent_id                    in number,
    p_parent_table                 in varchar2,
    p_effective_date               in date,
    p_phone_id                     in out number,
    p_object_version_number        in out number
)
is
   l_date_from                     date;
   l_phone_type                    varchar2(4000);
   l_phone_number                  varchar2(4000);
   l_parent_id                     number;
   l_parent_table                  varchar2(4000);
   l_effective_date                date;
   l_phone_id                      number;
   l_object_version_number         number;
  
begin
    l_date_from             := p_date_from;
    l_phone_type            := p_phone_type;
    l_phone_number          := p_phone_number;
    l_parent_id             := p_parent_id;
    l_parent_table          := p_parent_table;
    l_effective_date        := p_effective_date;
    l_phone_id              := p_phone_id;
    l_object_version_number := p_object_version_number;

    hr_phone_api.create_or_update_phone (
    p_date_from              => l_date_from,
    p_phone_type             => l_phone_type,
    p_phone_number           => l_phone_number,
    p_parent_id              => l_parent_id,
    p_parent_table           => l_parent_table,
    p_effective_date         => l_effective_date,
    p_phone_id               => l_phone_id,
    p_object_version_number  => l_object_version_number
  );
  
end create_or_update_phone;

end sp_create_or_update_phone;
