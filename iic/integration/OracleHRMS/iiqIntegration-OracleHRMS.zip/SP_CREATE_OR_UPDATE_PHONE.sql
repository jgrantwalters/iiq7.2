create or replace Package sp_create_or_update_phone as

procedure create_or_update_phone (
    p_date_from                    in date,
    p_phone_type                   in varchar2,
    p_phone_number                 in varchar2,
    p_parent_id                    in number,
    p_parent_table                 in varchar2,
    p_effective_date               in date,
    p_phone_id                     in out number,
    p_object_version_number        in out number
);

end sp_create_or_update_phone;
