The JDBC Stored Procedure provisioning assembly line is a simple example that
provisions accounts to a database table by calling stored procedures.  To use
a different database, you must just include the JDBC driver jar file in TDI's
classpath and change the connection setting (JDBC URL, Driver, etc...).

To use the example JDBC Stored Procedure provisioning assembly line, it is
required to run a database with a USERS table and a set of stored procedures
available to be executed.  The following DDL can be used on a Sybase database
to create the appropriate database, table structure, and stored procedures.
Note that you will also need to put the appropriate JDBC jar file in the
classpath of TDI or in the directory specified in the com.ibm.di.userjars
property.  A Sybase JDBC driver can be downloaded here:
http://jtds.sourceforge.net/.


use master
go

create database hr on master = 2
go

use hr
go 

setuser 'dbo'
go 

create table users (
	username                        varchar(128)                     not null  ,
	firstname                       varchar(128)                         null  ,
	lastname                        varchar(128)                         null  ,
	fullname                        varchar(128)                         null  ,
	email                           varchar(128)                         null  ,
	passwd                          varchar(128)                         null  ,
	groups                          varchar(1024)                        null  ,
	disabled                        tinyint                          not null  ,
	locked                          int                              not null   
)
lock allpages
 on 'default'
go 

create procedure create_hr_user
  (@username varchar(128),
   @firstname varchar(128),
   @lastname varchar(128),
   @fullname varchar(128),
   @email varchar(128),
   @passwd varchar(128),
   @groups varchar(1024),
   @disabled tinyint,
   @locked tinyint
  )
  AS
    insert into users (username, firstname, lastname, fullname, email, passwd, groups, disabled, locked) values (@username, @firstname, @lastname, @fullname, @email, @passwd, @groups, @disabled, @locked)
go

create procedure update_hr_user
  (@username varchar(128),
   @firstname varchar(128),
   @lastname varchar(128),
   @fullname varchar(128),
   @email varchar(128),
   @passwd varchar(128),
   @groups varchar(1024),
   @disabled tinyint,
   @locked tinyint
  )
  AS
    update users set firstname = @firstname, lastname = @lastname, fullname = @fullname, email = @email, passwd = @passwd, groups = @groups, disabled = @disabled, locked = @locked
     where username = @username
go

create procedure read_hr_user
  (@username varchar(128))
  AS
    select * from users where username = @username
go

create procedure delete_hr_user
  (@username varchar(128))
  AS
    delete from users where username = @username
go

create procedure disable_enable_hr_user
  (@username varchar(128),
   @disabled tinyint)
  AS
    update users set disabled = @disabled where username = @username
go

create procedure lock_unlock_hr_user
  (@username varchar(128),
   @locked tinyint)
  AS
    update users set locked = @locked where username = @username
go


sp_procxmode create_hr_user, "anymode"
go
sp_procxmode update_hr_user, "anymode"
go
sp_procxmode read_hr_user, "anymode"
go
sp_procxmode delete_hr_user, "anymode"
go
sp_procxmode disable_enable_hr_user, "anymode"
go
sp_procxmode lock_unlock_hr_user, "anymode"
go

setuser
go 
