---------------------------------------
TDI Assembly Line for SAP ABAP UserStore
Last updated: 04/08/2011
---------------------------------------

This connector is used to manage the users of the SAP ABAP
which is the backend user store for SAP where Roles
and Profiles are defined.

This assembly line requires 'TDI's SAP User Registry Connector' 
which is only shippped with the Identity version of TDI. This
assembly line was developed on version 7.0 of TDI.

There are two other 'user stores' in SAP, one for HR and 
the other for SAP Portal both will be addressed in other 
assembly lines.

There are four main steps to get this connector setup/configured:

1) Install SAPs JCO (version2) into TDI Install Directory 
   ($TDI_INSTALL/libs amd $TDI_INSTALL/jars)
2) Install our XSL files into TDI Install Directory 
   ($TDI_INSTALL/xsl)
3) Install our jar iiqIntegration.jar and iiqAssemblyLines.jar files into
   $TDI_INSTALL/jars
4) Import the SAP assemblyline into TDI and configure connection parameters 
   to the SAP Connector

---
JCO
---

The underlying connector in TDI uses the JCO interface, but 
unlike the IIQ connector this uses the jco 2.x source base.

NOTE: There are two distinct versions of JCO version 2 and 
version 3.  For the IIQ Connector we use version 3, but for 
this TDI connector they use the older version 2 source base, 
so make sure you get the correct version.

The docs state you can use:
    SAP Java Connector (JCo) version 2.1.6 or above

This means any version above 2.1.6 in the version 2
source stream.

Basically to get TDI JCO enabled you ou have to take the jco jar 
and native libaries and deploy it into the TDI installation
directory structure.  There is a 'jars' directory
relative to the tdi directlry where you deploy the sapjco.jar
and then there is a 'libs' directory also relative to the 
install dir where you place the two .dll files necssary
librfc32.dll and sapjcorfc.dll. ( at least on windows )

I also had to add these to lines to my services file.
$WINDIR/system32/drivers/etc/services

sapdp01         3201/tcp
sapgw01         3301/tcp

Complete information here in the user's guide:

http://publib.boulder.ibm.com/infocenter/tivihelp/v2r1/index.jsp?topic=%2Fcom.ibm.IBMDI.doc_7.0%2Freferenceguide106.htm

----------------------------------
XSL Files/XML/ Assembly Line Info
----------------------------------

The assembly line takes the XML returned from the Connector, parses it
into an object integration.tdi.sap.SapUser

The SapUser object is then used during the operations and then
serialized back into the assembly line once the changes have
been applied to the object model.

Then once serialized back into the assembly line, the connector uses
xsl style sheets to format the SapUser and connector
config to produce BAPI xml structures that are ultimatately
used to call the JCO BAPI libraries.

At different phases of the connector lifecycle it'll execute the style
sheets against the model to produce this bapi meta language.  Because
of this we need to also ship a series of xsl stylesheets. They are
included in our connector deliverables in a xsl directory relative 
to the TDI install path.

The files you need to copy over are :

iiq_bapi_user_actgroups_assign.xsl
iiq_bapi_user_change.xsl
iiq_bapi_user_create.xsl
iiq_bapi_user_delete.xsl
iiq_bapi_user_getdetail_postcall.xsl
iiq_bapi_user_getdetail_precall.xsl
iiq_bapi_user_profiles_assign.xsl
iiq_bapi_user_unlock.xsl

We handle all of the xml serialization in Java and have some data
classes shipped in iiqAssemblyLines.jar that need to be 
deployed along with the iiqIntegration.jar.

I was able to replace the .xsl files without restarting
the TDI server.

-----
JARS
-----

As mentioned earlier this connector requires an extra jar
named iiqAssemblyLines.jar which needs to be put in the
$TDI_INSTALL_DIR/jars directory.  

The iiqIntegrations.jar file is also required as it is
a prerequisit to the assemblyLine jar file.

--------------------
Functionality Notes
--------------------

The connector supports the following provisioning activites:

  Create
  Update (including roles, user groups and profiles)
  Password Change
     This is an administrative reset only. This means that users will be 
     prompted for a new password the next time they login to SAP.
  Delete
  Unlock

The xml representation of the user data makes the attributes
supported a little less obvious then some of the other assembly
lines.  For this assembly line there are only two attributes
attributes in the schema one named sapUserXml and the other
is sapUserName.

Here I'll outlike the supported attributes for
provisioning. 

Attributes supported:

  * = value required for create 
    ( technically this could vary from environment to environement but
      in our test bed these were the required ones ) 

  IIQ               TDI
  ---------------------------------
  *User Name          sapUserName 
  *password           password 
  *Last name          lastName 
  Academic Title      academicTitle
  Alias               alias
  Building            buildingNumber
  City                city
  Company             companyNameKey
  Company Address     name
  Company Address2    name2
  Company Address3    name3
  Company Address4    name4
  Country             country
  Department          department
  Fax                 primaryFaxNumber
  Fax Extension       primaryFaxExtension
  First name          firstName
  Floor               buildingFloor
  Format              nameFormat
  Function            function
  House Number        houseNumber
  Language ISO        isoLanguage
  Logon Language      logonLanguage
  Name Country        nameFormatRuleCountry
  PO Box              poBox
  Postal Code         postCode
  Postal Code2        poBoxPostCode
  Prefix 1            namePrefix
  Profiles            Profiles
  Region              region
  Roles               Roles
  Room Number         roomNumber
  Search Term P       searchSortTerm
  Street Address      street
  Street Number       streetNumber
  Telephone           primaryPhoneNumber
  Telephone Extension primaryPhoneNumberExtension
  TimeZone            timezone
  Title               title
  User Groups         User Groups
  User Last Login     lastLoginTime
  User Type           userType
  User Valid From     validFromDate
  User Valid To       validToDate
 
In addition:

  N/A                 Systems ( CUA Systems user is assigned )

These attributes will be automatically mapped from the IIQ
attributes when provisioning requests are made. So the incommig
ProvisioningPlans can contain either the IIQ name or the 
TDI Connector attribute.

-----------
CUA Support
-----------

For CUA Support you must also pull over a few extra
xsl files that set/fetch cua specific fields.

There is a separate assembly line for the CUA environment
that includes some additional xsl files and does some
additional processing to get the current profiles
and roles ino the TDI environment.

iiq_bapi_user_cua_systems_assign.xsl
iiq_bapi_user_localprofiles_assign.xsl
iiq_bapi_user_profiles_assign.xsl

There  are three different fields that are interesting
from a CUA Perspective.

You'll need to add three new attributes to your SAP
application in the IIQ environment when working 
in a CUA Environment.  The attributes are LocalProfiles, 
LocalRoles and Systems.

o LocalProfiles 
    Read:
    BAPI_USER_LOCPROFILES_READ

    Write:
    BAPI_USER_LOCPROFILES_ASSIGN
    BAPI_USER_LOCPROFILES_DELETE

    Syntax:
      Will be returned and must be set in the format :
           $server\$profileName

           e.g. AMDCLNT001\SAP_AL

o LocalRoles

    Read:
    BAPI_USER_LOCACTGROUPS_READ

    Write:
    BAPI_USER_LOCACTGROUPS_ASSIGN
    BAPI_USER_LOCACTGROUPS_DELETE

    Syntax:
      Will be returned and must be set in the format:
           $server\$roleName

           e.g. ERDCLNT001\SAP_S_RFCACL

o Systems ( CUA Systems ) 

  READ: SYSTEMS table in result of BAPI_USER_GET_DETAIL
    SUBSYSTEM column

  WRITE: 
    BAPI_USER_SYSTEM_ASSIGN

   Just a list of CUA systems, multivalued string

As you can see the "Local" version of the Role and Profile
attributes have a specially formatted attribute
value specifying the Server where the assignment to 
the role should be made.

This is the format the values are stored on links,
as well as the format that we expect over in
the TDI assembly line.  

All provisioning should happen at the CUA server and then
data is propagated down to the children systems at some point.  
This means the application (our application) needs to point 
to ERD.

These child role assignments will grant users 
tcodes (access to ui parts) on the child system.

Most of the time its believed that customers will
have the exact same role set acrosss all servers
in a CUA setup. The CUA Server and all child
servers will have a replication schedule where
things from the CUA server are pushed down to
the child servers.

One issue we have with SAP CUA and these CUA local roles is 
when loading account groups and ALSO the "group"
flag in the account schema.

Why is any of this important to the is group flag?

The group flag in the schema a turns an entitlement value into a 
clickable link in the UI which assumes it can resolve to an
account group. 

Basically we have some ui code that given the entitlement name, value
and application we can get back at a given account group
and display it in a popup.

For example:

roles=Z_SAP_S_RFCACL, Z_SAP_S_RFCACL1, Z_SAP_S_RFCACL2

Lets say you click on Z_SAP_S_RFCACL.

That would translate to find me the account group
where the app is the SAPCUA, the references attribute is the name
of the entitlement (roles) AND where the nativeIdentity is the attribute 
value. ( Z_SAP_S_RFCACL)

For example in a filter:

Filter.and(Filter.eq("application", app),  // we always have the app
           Filter.eq("referenceAttribute", "roles"),
           Filter.eq("nativeIdentity", "Z_SAP_S_RFCACL")
          );

When in a CUA environment the role entitlements will have
the server prefix.

The values are like AMDCLNT001\Z_SAP_S_RFCACL, etc..
This means to use the group flag we'd have to 
aggregate from each child system, or at least
duplicate each account group so it can be 
resolved.

