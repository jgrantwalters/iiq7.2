The Active Directory provisioning assembly line provisions Active Directory and
Exchange accounts.  This uses the LDAP interface to Active Directory.  In
order to set passwords on Active Directory, SSL must be enabled.  Follow the
instructions below to configure this.


CONFIGURING ACTIVE DIRECTORY FOR SSL
------------------------------------
Active Directory only allows setting passwords via LDAP over a secure
connection.  As such, you must configure Active Directory to support SSL and
import Active Directory's certificate into a trust store used by TDI.  Full
instructions can be found in the TDI documentation:

http://publib.boulder.ibm.com/infocenter/tivihelp/v2r1/topic/com.ibm.IBMDI.doc_7.0/adminguide35.htm#wq225


In practice, I used the following steps.  These differ slightly from the
instructions in the TDI documentation by being slightly simplified and ensuring
that the trust store still allows access through the TDI Server Remote API.

1) Setup Active Directory for SSL by following step 1 in the TDI documentation.
2) Retrieve the CA certificate from the Domain Controller.  Instead of following
   steps 2-4 in the TDI documentation, you can just copy the certificate from
   the Domain Controller if you have access to the file system.  This can be
   found in c:\ and will be named something like
   c:\snorkel.snorkelad.localhost_Snorkel CA.crt.
3) Import the CA certificate into a trust store that will be used the Active
   Directory (LDAP) connector in TDI.  Follow steps 5 and 6 in the TDI
   documentation to accomplish this with the following changes:
   a) Instead of editing root_dir/global.properties in step 6, you can edit
      solution.properties in the solution directory (eg - c:\Documents and
      Settings\Administrator\TDI 7.0).
   b) Only specify the java.net.ssl.trustStore* properties in step 6.  The
      keyStore properties can remain as they are.
   c) The default trust store has a trustedCertEntry that is required for the
      TDI config editor to work.  This also needs to be imported into the new
      store.  To do this, first export the server cert from the default trust
      store and import it into the new trust store.

      keytool -export -alias server -file tdiServerApi.cer -keystore C:\Documents and Settings\Administrator\My Documents\TDI 7.0\serverapi\testadmin.jks
      keytool -import -alias server -file tdiServerApi.cer -keystore c:\adssl.jks
4) Enable SSL for the AD connector and change the port (step 6 of the TDI docs).
