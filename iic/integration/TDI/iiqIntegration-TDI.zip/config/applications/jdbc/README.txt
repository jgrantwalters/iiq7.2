The JDBC provisioning assembly line is a simple example that provisions accounts
to a database table.  To use a different database, you must just include the
JDBC driver jar file in TDI's classpath and change the connection setting (JDBC
URL, Driver, etc...).

To use the example HR provisioning assembly line, it is required to run a
database with a USERS table.  The following DDL can be used on a MySQL database
to create the appropriate database and table structure.  Note that you will also
need to put the appropriate JDBC jar file in the classpath of TDI or in the
directory specified in the com.ibm.di.userjars property.  The MySQL JDBC
connector can be downloaded here:
http://dev.mysql.com/downloads/connector/j/5.1.html.


create database if not exists hr;

create table users (
  username varchar(128) NOT NULL,
  firstname varchar(128),
  lastname varchar(128),
  fullname varchar(128),
  email varchar(128),
  groups varchar(1024),
  passwd varchar(128),
  disabled tinyint DEFAULT '0',
  locked tinyint DEFAULT '0',
  PRIMARY KEY (username)
) ENGINE=InnoDB
