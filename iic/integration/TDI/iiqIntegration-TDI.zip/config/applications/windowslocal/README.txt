
---------------------------------------
TDI Assembly Line for Windows Local
Last updated: 12/7/2010
---------------------------------------

This connector is used to manage the users of Windows
Local Accounts.

The Connector is designed to connect to the Windows NT4 and Windows 2000 
SAM databases through the Win32 API for Windows NT and Windows 2000/2003 
user and group accounts. You can connect to a Windows 2000 SAM database, 
but the Connector only reads or writes attributes that are 
backward-compatible with NT4 (in other words, the Windows Users and 
Groups Connector has a predefined and static attribute map table 
consisting of NT4 attributes). Windows 2000/2003 native 
attributes or user-defined attributes are therefore not supported by 
this Connector.

This assembly line requires TDI's Windows Users and Groups
Connector which is only shippped with the Identity version of TDI. 
This assembly line was developed on version 7.0 of TDI.

The machine IBM� Tivoli Directory Integrator is running on must be in the same
Domain or Workgroup as the target system.

This likely means that we will require a TDI Server per local box.

Additionally for READ functionality we'll need to deploy a IQService
somewhere in their environment that is able to access the local
boxes via the network.  

NOTE : Seperate IQService installations may
be necessary depending on the installed windows 
nework topology.

--------------------
Functionality Notes
--------------------

The connector supports the following provisioning activites:

  Create
  Update 
  Password Change
  Delete
  Unlock
  Disable 
  Enable

  * = value required for create 

  IIQ               TDI
  ---------------------------------
  Description       AccountComment
                    ApplicationsParams
                    AuthFlags
                    BadPasswordCnt
                    CodePage
                    CountryCode
  UserFlags         Flags
  *FullName          FullName
  *GlobalGroups     GlobalGroups
  HomeDirectory     HomeDirectory
                    HomeDirectoryDrive
                    LastLogoff -  RO
                    LastLogon - RO
  **LocalGroups      LocalGroups
                    LogonHours
                    LogonServer
                    LogonWorkstations
                    LogonsNum - RO
  MaxStorage        MaxAccDiskSpace
  *password          Password - WO
                    PasswordAge - RO
                    PasswordExpired - RO
                    PrimaryGroup 
                    PrimaryGroupI
                    PrivilegeLevel -
                    ProfilePath
                    RelativeUserID
                    ScriptPath
                    UnitsPerWeek
                    UserComment
  *sAMAccountName    UserName

**
The LocalGroups and GlobalGroups attributes must be added to 
the Windows Local version of the connector. By default
the connector returns only the 'groups' attribute which
contains a single list of fully-qualfied group names.

The new LocalGroups and GlobalGroups collation 
was added in 5.1.x (post 5.1) and requires an IQService 
upgrade.

