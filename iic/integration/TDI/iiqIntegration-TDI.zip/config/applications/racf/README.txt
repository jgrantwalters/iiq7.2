The RACF provisioning assembly line provision RACF accounts.  This assembly line
uses the LDAP interface to RACF, which is also referred to as the SDBM backend
for the IBM Tivoli Directory Server on z/OS.  The following administration guide
has information on how to configure and use this:
http://publibfp.dhe.ibm.com/epubs/pdf/glpa2a70.pdf.
