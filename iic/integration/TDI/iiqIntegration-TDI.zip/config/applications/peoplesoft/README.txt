The PeopleSoft connector communicates to the PeopleSoft server through component interfaces.  To use
this connector, you must first configure the component interfaces on PeopleSoft.  This requires the
following steps:

1) Create the Component Interfaces
2) Create and copy the required jar files
3) Configure Component Interface security


CREATE THE COMPONENT INTERFACES
-------------------------------
1) Login to the PeopleTools Application Designer.
2) Unzip the tdi.zip file in integration/TDI to a temporary directory.
3) Select Tools -> Copy Project -> From File... and browse to the temporary directory from step 2.
   Browse to config/applications/peoplesoft and highlight the IIQ_CONN directory.
4) Select the IIQ_CONN project to open it.
5) Highlight Component Interfaces and click Copy to copy the project into PeopleSoft.


CREATE AND COPY THE REQUIRED JAR FILES
--------------------------------------
The following jars must be copied from the PeopleSoft server:
  - iiqPeopleSoftCompInt.jar
  - psjoa.jar

The iiqPeopleSoftCompInt.jar file contains the PeopleSoft Component Interface java classes. It
must be generated from the respective PeopleSoft resource and then copied in the
ITDI_HOME\jars\3rdParty\others directory on the workstation where the connector is installed.

Perform the following steps to create the iiqPeopleSoftCompInt.jar file from the Component
interface java files.

1) Logon to PeopleSoft Application Designer in two tier mode.
2) Open the IIQ_CONN Component Interface project and open all the component interfaces by double
   clicking each component interface.
3) From the menu select Build -> PeopleSoft APIs.
4) From the Build PeopleSoft API Bindings window, select the JAVA classes Build checkbox and clear
   the COM Type Library and C Header Files Build check boxes.
5) In the JAVA Classes frame check Build and select the appropriate Component Interfaces from the
   drop down menu. You must select the following options from the drop down menu:

     CompIntfc.CompIntfcPropertyInfo
     CompIntfc.CompIntfcPropertyInfoCollection
     PeopleSoft.* (all Component Interfaces that begin with the prefix PeopleSoft)
     CompIntfc.IIQ_* (all Component Interfaces that begin with the prefix CompIntfc.IIQ_)

    Note: If you need to generate Component Interface Java files for the entire group of Component
    Interfaces click ALL.

    Specify the appropriate file path for the JAVA files.  The Component Interface JAVA files are
    generated in the PeopleSoft\Generated\CompIntfc directory that is created in the specified
    location.  For example, if you specify C:\CI as the file path, then the Component Interface Java
    files are generated in C:\CI\PeopleSoft\Generated\CompIntfc.
6) Compile the JAVA files by performing the following steps:
    a. Open the command prompt and change directories to the folder where the generated JAVA files
       are located. For example, C:\CI. 
    b. Navigate to the PeopleSoft\Generated\CompIntfc\ directory.
    c. Run the following command:

         javac -classpath %PS_HOME%\class\psjoa.jar *.java

       Where %PS_HOME% is the location that PeopleSoft is installed.

       Note: Ensure that the JAVA compiler used for compiling the generated JAVA files is compatible
       with the JAVA provided with the PeopleSoft installation that needs to be managed.

    d. Optional: You can delete all the generated java files from the existing directory, however,
       do not delete the .class files. 
7) Perform the following steps to package the compiled files as the iiqPeopleSoftCompInt.jar file:
    a. Open the Command prompt and change directories to the folder where the generated JAVA files
       are located. For example cd C:\CI 
    b. Run the command: jar -cvf iiqPeopleSoftCompInt.jar *
8) Copy the generated iiqPeopleSoftCompInt.jar file to the ITDI_HOME\jars\3rdParty\others directory.
9) Copy psjoa.jar from %PS_HOME%\classes to the ITDI_HOME\jars\3rdParty\others directory.


In addition to the PeopleSoft jar file, the following jars should be copied from the IdentityIQ
installation image into the TDI classpath as follows (these can all be found in
integration/TDI/connectors.zip):
 - iiqConnector.jar -> ITDI_HOME\jars\3rdparty\others
 - iiqPeopleSoftConnector.jar -> ITDI_HOME\jars\3rdparty\others
 - iiqTdiConnectorAdapter.jar -> ITDI_HOME\jars\3rdparty\others
 - iiqTdiPeopleSoftConnector.jar -> ITDI_HOME\jars\3rdparty\connectors


CONFIGURE COMPONENT INTERFACE SECURITY
--------------------------------------
Before using the connector, you must allow the PeopleSoft user that the connector is configured with
to access the generated component interfaces.

To set security for the PeopleTools project:

1) Log into the PeopleSoft web interface.
2) Navigate to PeopleTools -> Security -> Permissions & Roles -> Permission Lists.
3) Click "Add a New Value" to create a new permission list.  Type "IIQ_ALL" as the name of the
   permission list, and click the "Add" button.
4) Click the Component Interfaces tab and add the following to the list:
    - IIQ_CURCODE
    - IIQ_DEL_ROLE
    - IIQ_DEL_USER
    - IIQ_IDTYPE
    - IIQ_LANG
    - IIQ_PERMLIST
    - IIQ_PSOPRALIAS
    - IIQ_ROLES
    - IIQ_USERS
5) For each added component interface, click the "Edit" link, click the "Full Access (All)" button,
   and click the "OK" button.
6) Click the "Save" button to save the new permission list.
7) Navigate to PeopleTools -> Security -> Permissions & Roles -> Roles.
8) Click "Add a New Value" to create a new role.  Type "IIQ_ROLE" as the name and click the "Add"
   button.
9) Type "Allows access to the IIQ component interfaces" as the description.
10) Click the "Permission Lists" tab and add the "IIQ_ALL" permission list.  Click the "Save" button
    to save the role.
11) Navigate to PeopleTools -> Security -> User Profiles, and select the user that is being used in
    the connector.
12) Click the "Roles" tab and add the "IIQ_ROLE" role.  Click the "Save" button to add the role to
    the user.
