
---------------------------------------
TDI Assembly Line for SAP HR
Last updated: 11/11/2010
---------------------------------------

This connector is used to manage the HR employees
store in SAP HR.

This assembly line requires 'TDI's SAP ABAP Application 
Server Business Object Repository Connector. 

This assembly line was developed on version 7.0 of TDI.

There are four main steps to get this connector setup/configured:

1) Install SAPs JCO (version2) into TDI Install Directory 
   ($TDI_INSTALL/libs amd $TDI_INSTALL/jars)
2) Install our XSL files into TDI Install Directory 
   ($TDI_INSTALL/xsl)
3) Install our jar iiqIntegration.jar and iiqAssemblyLines.jar files into
   $TDI_INSTALL/jars
4) Import the SAP HR assemblyline into TDI and configure connection parameters 
   to the SAP Connector

---
JCO
---

The underlying connector in TDI uses the JCO interface, but 
unlike the IIQ connector this uses the jco 2.x source base.

NOTE: There are two distinct versions of JCO version 2 and 
version 3.  For the IIQ Connector we use version 3, but for 
this TDI connector they use the older version 2 source base, 
so make sure you get the correct version.

The docs state you can use:
    SAP Java Connector (JCo) version 2.1.6 or above

This means any version above 2.1.6 in the version 2
source stream.

Basically to get TDI JCO enabled you ou have to take the jco jar 
and native libaries and deploy it into the TDI installation
directory structure.  There is a 'jars' directory
relative to the tdi directlry where you deploy the sapjco.jar
and then there is a 'libs' directory also relative to the 
install dir where you place the two .dll files necssary
librfc32.dll and sapjcorfc.dll. ( at least on windows )

I also had to add these to lines to my services file.
$WINDIR/system32/drivers/etc/services

sapdp01         3201/tcp
sapgw01         3301/tcp

Complete information here in the user's guide:

http://publib.boulder.ibm.com/infocenter/tivihelp/v2r1/index.jsp?topic=%2Fcom.ibm.IBMDI.doc_7.0%2Freferenceguide106.htm

----------------------------------
XSL Files/XML/ Assembly Line Info
----------------------------------

The assembly line takes the XML returned from the Connector, parses it
into an object integration.tdi.sap.SapPersonalData.

The SapPersonalData object is then used during the operations and then
serialized back into the assembly line once the changes have
been applied to the object model.

Then once serialized back into the assembly line, the connector uses
xsl style sheets to format the SapUser and connector
config to produce BAPI xml structures that are ultimatately
used to call the JCO BAPI libraries.

At different phases of the connector lifecycle it'll execute the style
sheets against the model to produce this bapi meta language.  Because
of this we need to also ship a series of xsl stylesheets. They are
included in our connector deliverables in a xsl directory relative 
to the TDI install path.

The files you need to copy over are :

iiq_bapi_employee_dequeue.xsl
iiq_bapi_employee_enqueue.xsl
iiq_bapi_persdata_change.xsl
iiq_bapi_persdata_create.xsl
iiq_bapi_persdata_delete.xsl
iiq_bapi_persdata_getdetail_postcall.xsl
iiq_bapi_persdata_getdetail_precall.xsl

We handle all of the xml serialization in Java and have some data
classes shipped in iiqAssemblyLines.jar that need to be 
deployed along with the iiqIntegration.jar.

NOTE:
I was able to replace the .xsl files without restarting
the TDI server.

-----
JARS
-----

As mentioned earlier this connector requires an extra jar
named iiqAssemblyLines.jar which needs to be put in the
$TDI_INSTALL_DIR/jars directory.  

The iiqIntegrations.jar file is also required as it is
a prerequisit to the assemblyLine jar file.

--------------------
Functionality Notes
--------------------

This TDI assembly line is NOT COMPLETE.

SAP HR has a very complicated onboarding process. By default
when you hire someone you have first run a process that creates
A employeeId by filling out data like, job code, salary manager,
date of employeement, etc.   Additionally the manager, and other
various things are configured.

The ui here is very involved because depending on what you
Enter in one box you get other required values in the 
Form and in some cases you can create new dependent
field objects. Like say this guys starting a new department, 
you can add a department, the hierarchy etc of that then 
come back and complete the user.

In any case, that process generates an employeeNumner, then 
from there you can update the HR personal record with 
information like employee ID.

It�s unclear if I can mimic that first part using the TDI connector,
its designed for infotype 1001 which is personal record. 
I am still researching that specific issue.

Then I started thinking about the uses cases here for
provisioning to this application.  It�s an HR system,
with likely NO entitlements, so would we create
accounts on this system?  


