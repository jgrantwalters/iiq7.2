The Unix provisioning assembly line provisions Unix accounts for many Unix and
Linux operating systems.  This assembly line performs provisioning commands by
remotely connecting to the Unix system via SSH, RSH, or telnet.
